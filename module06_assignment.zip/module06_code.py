#-------------------------------------------------#
# Title: Working with Functions and Classes
# Dev:   NRunyan
# Date:  May 15, 201
# ChangeLog: (Who, When, What): N/A
#-------------------------------------------------#

# Step 5)  Makes a class to hold the functions.
class Test_class(object):
# Creates object functions to be held within class.
# Step 1) Makes a function for your code that loads each row of data you have in the ToDo.txt file into a DICTIONARY
# and then appends those dictionaries into to a LIST.
    def row_loader(self, obj_file, items, lst_table, dic_new_row):
        self.obj_file = open("ToDo.txt", "r")
        self.lst_table = []
        for line in self.obj_file:
            self.items = line.strip().split(",")
            self.dic_new_row = {self.items[0]: self.items[1]} #places index items into a new dictionary row by 'key:value' format.
            self.lst_table.append(self.dic_new_row) #adds new dictionary row to list table.
        self.obj_file.close()
        return self.lst_table

# Step 2)
# Make a function for your code that displays the contents of the list to the user.
    def display_list(self, items, dic_new_row, lst_table):
        self.obj_file = open("ToDo.txt", "r")
        self.lst_table = []
        for line in self.obj_file:
            self.items = line.strip().split(",")
            self.dic_new_row = {self.items[0]: self.items[1]}
            self.lst_table.append(dic_new_row)
        self.obj_file.close()
        print("Your current database is: ", self.lst_table)
        return self.lst_table

    def add_item(self, str_task, str_priority):
        self.str_task = input("Please specify the new task: ")
        self.str_priority = input("Please specify the priority: ")
        self.dic_new_item = {self.str_task: self.str_priority}

        # writes that data to object file
        self.obj_file = open("ToDo.txt", "a")
        for line in self.obj_file:
            self.items = line.strip().split(",")
        for key, value in self.dic_new_item.items():
            self.obj_file.write("\n{},{}".format(key, value))
        print("Your new input data was saved.")
        self.obj_file.close()

    # Reads the 'dic_new_item' inputs and converts them into dictionary format.
        objFile = open("ToDo.txt", "r")
        for line in objFile:
            self.lst_table = []
            self.str_data = line
            self.dic_new_item = {(self.str_data.split(",")[0]).strip(), (self.str_data.split(",")[1]).strip()}
            self.lst_table.append(self.dic_new_item) # adds item to lst_table
        print("Your new database is: ", self.lst_table)
        self.objFile.close()
        return self.lst_table

    def remove_item(self, key, item, lst_table):
        item = 0
        for item in self.lst_table:
            if key in item:
                self.lst_table.remove(self.lst_table[item])
            item += 1

    # 4) Make a function for the code that saves the data from the table into the Todo.txt file when the program exits.
    def save_item(self, obj_file, lst_table):
        lst_table = []
        self.obj_file = open("ToDo.txt", "w")
        self.obj_file.write(str(lst_table))
        self.obj_file.close()
        print("Thank you! Your data was saved to the file ToDo.txt")


    def exit_prog(self, obj_file, lst_table):
        str_user_input = input("You haven't saved your work! Press any key to save and exit.")
        self.obj_file = open("ToDo.txt", "w")
        self.obj_file.write(str(self.lst_table))
        self.obj_file.close()
        print("Thank you! Your data was saved to the file ToDo.txt. Press any key to exit.")


# Step 3): Make a function for the code that allows the user to Add or Remove tasks from the list, plus save the tasks
# in the List tasks-priorities using numbered choices.
def main():
    tc = Test_class
    while True:
        int_choice = input("Which option would you like to perform? [0 - 3] - ")
        print("""
            Menu of Options
            0) Add task
            1) Remove task 
            2) Save Tasks 
            3) Save/Exit
            """)
        if int_choice == 0:
            tc.add_item(self, str_task, str_priority)

        elif int_choice == 1:
            tc.remove_item(self, key, item, lst_table)

        elif int_choice == 2:
            tc.save_item(self, obj_file, lst_table)

        elif int_choice == 3:
            tc.exit_prog(self, obj_file, lst_table)

    else: break

